from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path


def pid_is_running(pid: int) -> bool:
    if os.name == "nt":
        # tasklist returns info if PID exists.
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True,
            text=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        text = (result.stdout or "").strip().lower()
        return str(pid) in text and "no tasks are running" not in text

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def main() -> None:
    if len(sys.argv) < 4:
        raise SystemExit(1)

    old_pid = int(sys.argv[1])
    base_dir = Path(sys.argv[2]).resolve()
    delay = float(sys.argv[3])

    # Wait for the old Jarvis process to fully exit and release port 5000.
    deadline = time.time() + 30
    while time.time() < deadline and pid_is_running(old_pid):
        time.sleep(0.25)

    time.sleep(max(delay, 1.5))

    bot_path = base_dir / "bot.py"

    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    subprocess.Popen(
        [sys.executable, str(bot_path)],
        cwd=str(base_dir),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
        creationflags=creationflags,
    )


if __name__ == "__main__":
    main()

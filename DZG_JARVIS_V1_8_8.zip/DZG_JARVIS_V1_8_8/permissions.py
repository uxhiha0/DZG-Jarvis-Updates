from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).resolve().parent / "permissions_config.json"


def load_permissions() -> dict:
    if not PATH.exists():
        return {"guilds": {}}

    try:
        data = json.loads(PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"guilds": {}}
        data.setdefault("guilds", {})
        return data
    except Exception:
        return {"guilds": {}}


def save_permissions(data: dict) -> None:
    PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_staff_role_ids(guild_id: int) -> set[int]:
    data = load_permissions()
    guild = data["guilds"].get(str(guild_id), {})
    return {int(role_id) for role_id in guild.get("staff_role_ids", [])}



def get_dashboard_access_role_ids(guild_id: int) -> set[int]:
    guild_cfg = permissions_config.get("guilds", {}).get(str(guild_id), {})
    role_ids = guild_cfg.get("dashboard_access_role_ids", [])
    return {int(role_id) for role_id in role_ids}


def set_dashboard_access_role_ids(guild_id: int, role_ids) -> None:
    guilds = permissions_config.setdefault("guilds", {})
    guild_cfg = guilds.setdefault(str(guild_id), {})
    guild_cfg["dashboard_access_role_ids"] = [int(role_id) for role_id in role_ids]
    save_permissions_config()


def can_use_jarvis(member) -> bool:
    """Only the guild owner or approved Dashboard Access roles may use commands."""
    if member is None or member.guild is None:
        return False

    if member.id == member.guild.owner_id:
        return True

    allowed_roles = get_dashboard_access_role_ids(member.guild.id)
    return any(role.id in allowed_roles for role in member.roles)

def set_staff_role_ids(guild_id: int, role_ids: list[int]) -> None:
    data = load_permissions()
    guild = data["guilds"].setdefault(str(guild_id), {})
    guild["staff_role_ids"] = sorted({int(role_id) for role_id in role_ids})
    save_permissions(data)

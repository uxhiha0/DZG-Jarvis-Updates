from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).resolve().parent / "permissions_config.json"


def load_permissions() -> dict:
    if not PATH.exists():
        return {"guilds": {}}

    try:
        data = json.loads(PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"guilds": {}}
        data.setdefault("guilds", {})
        return data
    except Exception:
        return {"guilds": {}}


def save_permissions(data: dict) -> None:
    PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_staff_role_ids(guild_id: int) -> set[int]:
    data = load_permissions()
    guild = data["guilds"].get(str(guild_id), {})
    return {int(role_id) for role_id in guild.get("staff_role_ids", [])}


def set_staff_role_ids(guild_id: int, role_ids: list[int]) -> None:
    data = load_permissions()
    guild = data["guilds"].setdefault(str(guild_id), {})
    guild["staff_role_ids"] = sorted({int(role_id) for role_id in role_ids})
    save_permissions(data)

import hashlib
import json
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


if len(sys.argv) < 4:
    print(
        "Usage: python make_manifest.py "
        "<version> <update_zip> <public_zip_url> [changelog]"
    )
    raise SystemExit(1)

version = sys.argv[1]
zip_path = Path(sys.argv[2])
public_url = sys.argv[3]
changelog = sys.argv[4] if len(sys.argv) > 4 else ""

manifest = {
    "version": version,
    "zip_url": public_url,
    "sha256": sha256(zip_path),
    "changelog": changelog,
}

Path("version.json").write_text(
    json.dumps(manifest, indent=2),
    encoding="utf-8",
)

print("Created version.json")

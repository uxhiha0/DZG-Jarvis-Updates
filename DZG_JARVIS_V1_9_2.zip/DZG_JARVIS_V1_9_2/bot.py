from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import secrets
import urllib.error
import urllib.parse
import urllib.request
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv
from flask import Flask, abort, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from permissions import get_staff_role_ids, set_staff_role_ids, can_use_jarvis, get_dashboard_access_role_ids, set_dashboard_access_role_ids
from updater import (
    CURRENT_VERSION,
    UPDATE_STATE,
    apply_update,
    check_for_update,
    restart_process,
)

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "127.0.0.1").strip()
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", "5000"))
UPDATE_MANIFEST_URL = os.getenv("UPDATE_MANIFEST_URL", "").strip()

DISCORD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "").strip()
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "").strip()

REMOTE_ACCESS_ENABLED = (
    os.getenv("REMOTE_ACCESS_ENABLED", "false").strip().lower()
    in {"1", "true", "yes", "on"}
)
NGROK_AUTHTOKEN = os.getenv("NGROK_AUTHTOKEN", "").strip()
NGROK_DOMAIN = os.getenv("NGROK_DOMAIN", "").strip()
DASHBOARD_PUBLIC_URL = os.getenv("DASHBOARD_PUBLIC_URL", "").strip().rstrip("/")


def normalize_public_url(value: str) -> str:
    value = value.strip().rstrip("/")
    if not value:
        return ""

    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"

    parsed = urllib.parse.urlsplit(value)
    if not parsed.hostname:
        return ""

    return urllib.parse.urlunsplit(
        (
            parsed.scheme or "https",
            parsed.netloc,
            "",
            "",
            "",
        )
    ).rstrip("/")


if not DASHBOARD_PUBLIC_URL and NGROK_DOMAIN:
    DASHBOARD_PUBLIC_URL = normalize_public_url(NGROK_DOMAIN)
else:
    DASHBOARD_PUBLIC_URL = normalize_public_url(DASHBOARD_PUBLIC_URL)

if DASHBOARD_PUBLIC_URL:
    NGROK_DOMAIN = urllib.parse.urlsplit(DASHBOARD_PUBLIC_URL).hostname or NGROK_DOMAIN

# Keep the actual web server private to this PC. ngrok connects locally.
if REMOTE_ACCESS_ENABLED:
    DASHBOARD_HOST = "127.0.0.1"

DISCORD_REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "").strip()
if not DISCORD_REDIRECT_URI:
    if DASHBOARD_PUBLIC_URL:
        DISCORD_REDIRECT_URI = f"{DASHBOARD_PUBLIC_URL}/oauth/callback"
    else:
        DISCORD_REDIRECT_URI = (
            f"http://127.0.0.1:{DASHBOARD_PORT}/oauth/callback"
        )

AUTH_CONFIGURED = bool(
    DISCORD_CLIENT_ID
    and DISCORD_CLIENT_SECRET
    and DISCORD_REDIRECT_URI
)

REMOTE_ACCESS_CONFIGURED = bool(
    REMOTE_ACCESS_ENABLED
    and NGROK_AUTHTOKEN
    and NGROK_DOMAIN
    and DASHBOARD_PUBLIC_URL.startswith("https://")
    and AUTH_CONFIGURED
)

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing from .env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "fakeban_config.json"
HISTORY_PATH = BASE / "fakeban_history.json"

DATA_LOCK = threading.RLock()
BOT_LOOP = None
BOT_STARTED_AT = datetime.now(timezone.utc)
TREE_SYNCED = False

UPDATE_INSTALL_STATE = {
    "status": "idle",
    "message": "",
    "target_version": None,
}

REMOTE_STATE = {
    "enabled": REMOTE_ACCESS_ENABLED,
    "configured": REMOTE_ACCESS_CONFIGURED,
    "status": "disabled" if not REMOTE_ACCESS_ENABLED else "starting",
    "public_url": DASHBOARD_PUBLIC_URL,
    "error": "",
    "server": "starting",
}

HEADERS = [
    "🚨 **DZG BAN HAMMER AMBUSH** 🚨",
    "👑 **SUKUNA'S RANDOM JUDGMENT** 👑",
    "💀 **THE KING HAS SPOKEN** 💀",
    "⚔️ **DROP ZONE TRIBUNAL** ⚔️",
    "🔨 **DZG BAN HAMMER DEPLOYED** 🔨",
    "📢 **OFFICIAL DZG BAN NOTICE** 📢",
]

REASONS = [
    "said “one more game” three hours ago",
    "joined VC, said “yo,” and vanished",
    "claimed they were locked in and immediately sold the match",
    "blamed lag after missing every shot",
    "went AFK exactly when the squad needed them",
    "said “trust me” before making the worst decision imaginable",
    "forgot to mute while fighting a bag of chips",
    "has been suspiciously quiet and is clearly plotting something",
    "landed on the opposite side of the map from the squad",
    "said “I got this” moments before absolutely not having it",
    "stole the best loot and called it teamwork",
    "entered DZG with dangerous levels of confidence",
    "committed crimes against basic common sense",
    "was caught lurking without paying the DZG lurking tax",
    "pressed every button except the useful one",
    "forgot the objective because they were too busy looting",
    "called the game trash immediately after losing",
    "was caught being productive instead of gaming",
    "failed the sacred DZG vibe check by 0.01 points",
    "committed first-degree controller blaming",
    "was too powerful and had to be temporarily nerfed",
    "became the main character without filing the paperwork",
    "queued ranked while emotionally unprepared",
    "has not delivered Sukuna the required daily Victory Royale",
]

PUNISHMENTS = [
    "Immediate exile for 0.37 seconds.",
    "Banned until they finish reading this sentence.",
    "Sentenced to one full match with random teammates.",
    "Forced to watch the squad take their loot.",
    "Ban duration: one loading screen.",
    "Sentenced to stand in the corner and think about it.",
    "Sentenced to carry the squad next match.",
    "Their next good item legally belongs to the team.",
    "Banned for 24 hours in dog years.",
]

REVERSALS = [
    "**BAN OVERTURNED.** Unfortunately, we have decided to keep them.",
    "**APPEAL ACCEPTED.** They may continue causing problems.",
    "**PARDONED BY SUKUNA.** The kingdom shows mercy... this time.",
    "**CASE DISMISSED.** Nobody wanted to do the paperwork.",
    "**RELEASED ON BAIL.** Bail was exactly zero dollars.",
]

CLOSERS = [
    "Nobody knows when the next one is coming.",
    "The Ban Hammer sleeps with one eye open.",
    "The King is always watching.",
    "Court adjourned. For now.",
    "Stay active. Stay dangerous. Stay off the paperwork.",
]

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)
dashboard = Flask(__name__, template_folder=str(BASE / "templates"))

DASHBOARD_SECRET_PATH = BASE / "dashboard_secret.key"


def load_dashboard_secret() -> str:
    """Load a stable local Flask session secret without exposing it."""
    env_secret = os.getenv("FLASK_SECRET_KEY", "").strip()
    if env_secret:
        return env_secret

    if DASHBOARD_SECRET_PATH.exists():
        saved = DASHBOARD_SECRET_PATH.read_text(encoding="utf-8").strip()
        if saved:
            return saved

    generated = secrets.token_hex(32)
    DASHBOARD_SECRET_PATH.write_text(generated, encoding="utf-8")
    return generated


dashboard.secret_key = load_dashboard_secret()
dashboard.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=DASHBOARD_PUBLIC_URL.startswith("https://"),
    PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
)

# Trust one local reverse proxy (ngrok) for scheme and host information.
dashboard.wsgi_app = ProxyFix(
    dashboard.wsgi_app,
    x_for=1,
    x_proto=1,
    x_host=1,
)

trusted_hosts = {
    "127.0.0.1",
    f"127.0.0.1:{DASHBOARD_PORT}",
    "localhost",
    f"localhost:{DASHBOARD_PORT}",
}
if DASHBOARD_PUBLIC_URL:
    parsed_public_url = urllib.parse.urlsplit(DASHBOARD_PUBLIC_URL)
    if parsed_public_url.hostname:
        trusted_hosts.add(parsed_public_url.hostname)
    if parsed_public_url.netloc:
        trusted_hosts.add(parsed_public_url.netloc)

dashboard.config["TRUSTED_HOSTS"] = sorted(trusted_hosts)


def get_csrf_token() -> str:
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


@dashboard.context_processor
def inject_dashboard_security():
    return {"csrf_token": get_csrf_token}


@dashboard.after_request
def add_dashboard_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault(
        "Permissions-Policy",
        "camera=(), microphone=(), geolocation=(), payment=()",
    )
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; "
        "img-src 'self' https://cdn.discordapp.com "
        "https://*.discordapp.com data:; "
        "style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; "
        "connect-src 'self'; "
        "form-action 'self' https://discord.com; "
        "frame-ancestors 'none'; base-uri 'self'",
    )
    response.headers.setdefault("Cache-Control", "no-store")

    if request.is_secure:
        response.headers.setdefault(
            "Strict-Transport-Security",
            "max-age=31536000; includeSubDomains",
        )

    return response


def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        logging.exception("Could not read %s", path.name)
        return default


def save_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


config = load_json(CONFIG_PATH, {"guilds": {}})
history = load_json(HISTORY_PATH, {"entries": []})


def get_cfg(guild_id: int):
    with DATA_LOCK:
        cfg = config["guilds"].setdefault(str(guild_id), {})
        cfg.setdefault("channel_id", None)
        cfg.setdefault("enabled", True)
        cfg.setdefault("exclude_staff", True)
        cfg.setdefault("min_minutes", 180)
        cfg.setdefault("max_minutes", 720)
        cfg.setdefault("next_run_utc", None)
        save_json(CONFIG_PATH, config)
        return cfg


def is_staff(member: discord.Member) -> bool:
    permissions = member.guild_permissions

    if (
        permissions.administrator
        or permissions.manage_guild
        or permissions.manage_messages
        or permissions.moderate_members
    ):
        return True

    allowed_role_ids = get_staff_role_ids(member.guild.id)
    return any(role.id in allowed_role_ids for role in member.roles)


def normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def server_members(
    guild_id: int,
    exclude_staff: bool = False,
):
    """Return the guild's full cached member pool for fake-ban targeting.

    Bots are always excluded. Staff are excluded only when requested.
    Requires the Discord Server Members Intent to be enabled.
    """
    guild = bot.get_guild(guild_id)

    if guild is None:
        return []

    result = []

    for member in guild.members:
        if member.bot:
            continue

        staff = is_staff(member)

        if exclude_staff and staff:
            continue

        result.append(
            {
                "id": member.id,
                "name": member.display_name,
                "is_staff": staff,
            }
        )

    result.sort(key=lambda item: item["name"].casefold())
    return result


def choose_target(guild_id: int, exclude_staff: bool = True):
    members = server_members(
        guild_id,
        exclude_staff=exclude_staff,
    )

    return random.choice(members)["id"] if members else None


def generate_fakeban(user_id: int):
    reason = random.choice(REASONS)
    punishment = random.choice(PUNISHMENTS)
    reversal = random.choice(REVERSALS)
    closer = random.choice(CLOSERS)

    if random.random() < 0.08:
        message = (
            "🌑 **DOMAIN EXPANSION: MALEVOLENT BAN SHRINE** 🌑\n\n"
            f"<@{user_id}> has been summoned before **Sukuna, King of the Drop Zone**.\n\n"
            f"**CRIME:** {reason}.\n\n"
            "**THE VERDICT:** Guilty.\n\n"
            f"**SENTENCE:** {punishment}\n\n"
            f"{reversal}\n\n"
            f"{closer}"
        )
    else:
        message = (
            f"{random.choice(HEADERS)}\n\n"
            f"<@{user_id}> has officially been **BANNED FROM DZG**.\n\n"
            f"**Reason:** {reason}.\n\n"
            f"**Sentence:** {punishment}\n\n"
            f"{reversal}\n\n"
            f"{closer}\n\n"
            "— **Sukuna | Owner of DZG**"
        )

    return message, reason


def log_fakeban(
    guild_id: int,
    user_id: int,
    user_name: str,
    reason: str,
    source: str,
) -> None:
    with DATA_LOCK:
        history["entries"].insert(
            0,
            {
                "guild_id": guild_id,
                "user_id": user_id,
                "user_name": user_name,
                "reason": reason,
                "source": source,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        history["entries"] = history["entries"][:100]
        save_json(HISTORY_PATH, history)


def schedule_next(guild_id: int):
    with DATA_LOCK:
        cfg = get_cfg(guild_id)
        min_minutes = max(5, int(cfg["min_minutes"]))
        max_minutes = max(min_minutes, int(cfg["max_minutes"]))
        wait = random.randint(min_minutes, max_minutes)

        cfg["next_run_utc"] = (
            datetime.now(timezone.utc) + timedelta(minutes=wait)
        ).isoformat()

        save_json(CONFIG_PATH, config)
        return wait


def get_next(cfg):
    raw = cfg.get("next_run_utc")
    if not raw:
        return None

    try:
        return normalize_datetime(datetime.fromisoformat(raw))
    except Exception:
        return None


def member_name(guild_id: int, user_id: int):
    guild = bot.get_guild(guild_id)

    if guild is not None:
        member = guild.get_member(user_id)

        if member is not None:
            return member.display_name

    return str(user_id)


async def send_dashboard_fakeban(
    guild_id: int,
    target_id=None,
    source="dashboard-random",
):
    guild = bot.get_guild(guild_id)
    if not guild:
        return False, "Server not found."

    cfg = get_cfg(guild_id)
    channel_id = cfg.get("channel_id")

    if not channel_id:
        return False, "No fake-ban channel is configured."

    channel = guild.get_channel(int(channel_id))
    if not isinstance(channel, discord.TextChannel):
        return False, "Configured fake-ban channel could not be found."

    if target_id is None:
        target_id = choose_target(
            guild_id,
            cfg.get("exclude_staff", True),
        )

    if target_id is None:
        return False, "No eligible server members are available."

    message, reason = generate_fakeban(target_id)
    await channel.send(message)

    log_fakeban(
        guild_id,
        target_id,
        member_name(guild_id, target_id),
        reason,
        source,
    )

    return True, f"Fake ban sent for {member_name(guild_id, target_id)}."


def run_on_bot(coro, timeout=10):
    if BOT_LOOP is None:
        return False, "Jarvis is not connected to Discord yet."

    try:
        future = asyncio.run_coroutine_threadsafe(coro, BOT_LOOP)
        return future.result(timeout=timeout)
    except Exception as exc:
        logging.exception("Dashboard action failed")
        return False, str(exc)


async def require_staff(interaction: discord.Interaction) -> bool:
    if (
        not interaction.guild
        or not isinstance(interaction.user, discord.Member)
        or not is_staff(interaction.user)
    ):
        await interaction.response.send_message(
            "Staff only.",
            ephemeral=True,
        )
        return False
    return True


@bot.event
async def on_ready():
    global BOT_LOOP, TREE_SYNCED

    BOT_LOOP = asyncio.get_running_loop()

    print("=" * 64)
    print(f"DZG JARVIS V{CURRENT_VERSION} ONLINE: {bot.user}")
    print(f"Dashboard: http://{DASHBOARD_HOST}:{DASHBOARD_PORT}")
    print("=" * 64)

    if not TREE_SYNCED:
        try:
            synced = await bot.tree.sync()
            print(f"Synced {len(synced)} slash commands.")
            TREE_SYNCED = True
        except Exception as exc:
            print("Slash command sync error:", exc)

    for guild in bot.guilds:
        cfg = get_cfg(guild.id)
        if cfg["enabled"] and not get_next(cfg):
            schedule_next(guild.id)

    if not scheduler.is_running():
        scheduler.start()

    if not update_checker.is_running():
        update_checker.start()


@tasks.loop(minutes=1)
async def scheduler():
    now = datetime.now(timezone.utc)

    for guild in bot.guilds:
        cfg = get_cfg(guild.id)

        if not cfg["enabled"] or not cfg["channel_id"]:
            continue

        next_run = get_next(cfg)

        if not next_run:
            schedule_next(guild.id)
            continue

        if now < next_run:
            continue

        channel = guild.get_channel(int(cfg["channel_id"]))
        target = choose_target(guild.id, cfg["exclude_staff"])

        if target and isinstance(channel, discord.TextChannel):
            message, reason = generate_fakeban(target)
            await channel.send(message)
            log_fakeban(
                guild.id,
                target,
                member_name(guild.id, target),
                reason,
                "automatic",
            )

        schedule_next(guild.id)


@scheduler.before_loop
async def before_scheduler():
    await bot.wait_until_ready()


@tasks.loop(minutes=1)
async def update_checker():
    if UPDATE_MANIFEST_URL:
        await asyncio.to_thread(
            check_for_update,
            UPDATE_MANIFEST_URL,
        )


@update_checker.before_loop
async def before_update_checker():
    await bot.wait_until_ready()


@bot.tree.command(name="fakeban", description="Fake ban a specific member.")
async def fakeban(interaction: discord.Interaction, member: discord.Member):
    if not await require_staff(interaction):
        return

    message, reason = generate_fakeban(member.id)
    await interaction.response.send_message(message)

    log_fakeban(
        interaction.guild.id,
        member.id,
        member.display_name,
        reason,
        "slash-manual",
    )


@bot.tree.command(name="randomfakeban", description="Fake ban a random server member now.")
async def randomfakeban(interaction: discord.Interaction):
    if not await require_staff(interaction):
        return

    cfg = get_cfg(interaction.guild.id)
    target = choose_target(
        interaction.guild.id,
        cfg["exclude_staff"],
    )

    if not target:
        await interaction.response.send_message(
            "No eligible server members are available.",
            ephemeral=True,
        )
        return

    message, reason = generate_fakeban(target)
    await interaction.response.send_message(message)

    log_fakeban(
        interaction.guild.id,
        target,
        member_name(interaction.guild.id, target),
        reason,
        "slash-random",
    )


@bot.tree.command(
    name="setfakebanchannel",
    description="Set this channel for random fake bans.",
)
async def setfakebanchannel(interaction: discord.Interaction):
    if not await require_staff(interaction):
        return

    cfg = get_cfg(interaction.guild.id)
    cfg["channel_id"] = interaction.channel_id
    save_json(CONFIG_PATH, config)

    if not get_next(cfg):
        schedule_next(interaction.guild.id)

    await interaction.response.send_message(
        f"Random fake bans will post in <#{interaction.channel_id}>.",
        ephemeral=True,
    )


@bot.tree.command(
    name="setrandomfakebanwindow",
    description="Set the shortest and longest wait between random fake bans.",
)
@app_commands.describe(
    min_minutes="Minimum wait in minutes",
    max_minutes="Maximum wait in minutes",
)
async def setrandomfakebanwindow(
    interaction: discord.Interaction,
    min_minutes: app_commands.Range[int, 5, 10080],
    max_minutes: app_commands.Range[int, 5, 10080],
):
    if not await require_staff(interaction):
        return

    if max_minutes < min_minutes:
        await interaction.response.send_message(
            "Max minutes must be greater than or equal to min minutes.",
            ephemeral=True,
        )
        return

    cfg = get_cfg(interaction.guild.id)
    cfg["min_minutes"] = int(min_minutes)
    cfg["max_minutes"] = int(max_minutes)
    wait = schedule_next(interaction.guild.id)

    await interaction.response.send_message(
        f"Random window set to **{min_minutes}–{max_minutes} minutes**. "
        f"Next ambush rolled for about **{wait} minutes** from now.",
        ephemeral=True,
    )


@bot.tree.command(
    name="fakebantoggle",
    description="Turn random fake bans on or off.",
)
async def fakebantoggle(
    interaction: discord.Interaction,
    enabled: bool,
):
    if not await require_staff(interaction):
        return

    cfg = get_cfg(interaction.guild.id)
    cfg["enabled"] = enabled

    if enabled:
        schedule_next(interaction.guild.id)
    else:
        save_json(CONFIG_PATH, config)

    await interaction.response.send_message(
        f"Random fake bans are now **{'ON' if enabled else 'OFF'}**.",
        ephemeral=True,
    )


@bot.tree.command(
    name="fakebanstaff",
    description="Include or exclude staff from random selection.",
)
async def fakebanstaff(
    interaction: discord.Interaction,
    include_staff: bool,
):
    if not await require_staff(interaction):
        return

    cfg = get_cfg(interaction.guild.id)
    cfg["exclude_staff"] = not include_staff
    save_json(CONFIG_PATH, config)

    await interaction.response.send_message(
        f"Staff are now **{'included' if include_staff else 'excluded'}**.",
        ephemeral=True,
    )


@bot.tree.command(
    name="fakebanstatus",
    description="Show random fake-ban settings.",
)
async def fakebanstatus(interaction: discord.Interaction):
    if not await require_staff(interaction):
        return

    cfg = get_cfg(interaction.guild.id)
    next_run = get_next(cfg)

    next_text = (
        f"<t:{int(next_run.timestamp())}:R>"
        if next_run
        else "Not scheduled"
    )

    channel_text = (
        f"<#{cfg['channel_id']}>"
        if cfg["channel_id"]
        else "Not configured"
    )

    await interaction.response.send_message(
        "**DZG Jarvis Random Fake Ban Mode**\n"
        f"Automatic: **{'ON' if cfg['enabled'] else 'OFF'}**\n"
        f"Channel: {channel_text}\n"
        f"Random window: **{cfg['min_minutes']}–{cfg['max_minutes']} minutes**\n"
        f"Staff excluded: **{'YES' if cfg['exclude_staff'] else 'NO'}**\n"
        f"Next ambush: {next_text}",
        ephemeral=True,
    )


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, _ = divmod(seconds, 60)

    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    parts.append(f"{minutes}m")
    return " ".join(parts)


DISCORD_OAUTH_AUTHORIZE_URL = "https://discord.com/oauth2/authorize"
DISCORD_OAUTH_TOKEN_URL = "https://discord.com/api/oauth2/token"
DISCORD_API_ME_URL = "https://discord.com/api/users/@me"


def current_dashboard_user():
    return session.get("discord_user")


def discord_avatar_url(user: dict) -> str:
    user_id = str(user.get("id", ""))
    avatar = user.get("avatar")

    if user_id and avatar:
        return (
            f"https://cdn.discordapp.com/avatars/"
            f"{user_id}/{avatar}.png?size=128"
        )

    if user_id.isdigit():
        default_index = (int(user_id) >> 22) % 6
    else:
        default_index = 0

    return (
        "https://cdn.discordapp.com/embed/avatars/"
        f"{default_index}.png"
    )


def user_can_access_guild(user_id: int, guild: discord.Guild) -> bool:
    if guild.owner_id == user_id:
        return True

    member = guild.get_member(user_id)
    if member is None:
        return False

    return can_use_jarvis(member)


def authorized_guilds_for_session():
    guilds = list(bot.guilds)

    # Local setup mode keeps the existing dashboard available until OAuth
    # credentials are configured. Once OAuth is configured, login is required.
    if not AUTH_CONFIGURED:
        return guilds

    user = current_dashboard_user()
    if not user:
        return []

    try:
        user_id = int(user["id"])
    except (KeyError, TypeError, ValueError):
        return []

    return [
        guild
        for guild in guilds
        if user_can_access_guild(user_id, guild)
    ]


def require_guild_access(guild_id: int) -> None:
    if not AUTH_CONFIGURED:
        return

    user = current_dashboard_user()
    if not user:
        abort(401)

    guild = bot.get_guild(guild_id)
    if guild is None:
        abort(404)

    try:
        user_id = int(user["id"])
    except (KeyError, TypeError, ValueError):
        abort(401)

    if not user_can_access_guild(user_id, guild):
        abort(403)


def oauth_exchange_code(code: str) -> dict:
    payload = urllib.parse.urlencode(
        {
            "client_id": DISCORD_CLIENT_ID,
            "client_secret": DISCORD_CLIENT_SECRET,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": DISCORD_REDIRECT_URI,
        }
    ).encode("utf-8")

    token_request = urllib.request.Request(
        DISCORD_OAUTH_TOKEN_URL,
        data=payload,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": f"DZG-Jarvis/{CURRENT_VERSION}",
        },
        method="POST",
    )

    with urllib.request.urlopen(token_request, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def oauth_fetch_user(access_token: str) -> dict:
    user_request = urllib.request.Request(
        DISCORD_API_ME_URL,
        headers={
            "Authorization": f"Bearer {access_token}",
            "User-Agent": f"DZG-Jarvis/{CURRENT_VERSION}",
        },
    )

    with urllib.request.urlopen(user_request, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


@dashboard.before_request
def dashboard_auth_guard():
    endpoint = request.endpoint or ""

    if request.method == "POST":
        expected_token = session.get("_csrf_token", "")
        supplied_token = (
            request.form.get("_csrf_token", "")
            or request.headers.get("X-CSRF-Token", "")
        )

        if (
            not expected_token
            or not supplied_token
            or not secrets.compare_digest(expected_token, supplied_token)
        ):
            abort(400)

    public_endpoints = {
        "dashboard_login",
        "dashboard_oauth_callback",
        "dashboard_auth_status",
    }

    if endpoint in public_endpoints or endpoint == "static":
        return None

    if not AUTH_CONFIGURED:
        return None

    if not current_dashboard_user():
        return redirect(
            url_for(
                "dashboard_login",
                next=request.full_path if request.query_string else request.path,
            )
        )

    # Every current dashboard POST that modifies server state includes guild_id.
    if request.method == "POST" and request.form.get("guild_id"):
        try:
            require_guild_access(int(request.form["guild_id"]))
        except ValueError:
            abort(400)

    return None


@dashboard.get("/login")
def dashboard_login():
    if not AUTH_CONFIGURED:
        return render_template(
            "login.html",
            auth_configured=False,
            redirect_uri=DISCORD_REDIRECT_URI,
        )

    if current_dashboard_user():
        return redirect(url_for("dashboard_home"))

    state = secrets.token_urlsafe(32)
    session["oauth_state"] = state
    session["oauth_next"] = request.args.get("next", "/")

    params = urllib.parse.urlencode(
        {
            "client_id": DISCORD_CLIENT_ID,
            "redirect_uri": DISCORD_REDIRECT_URI,
            "response_type": "code",
            "scope": "identify",
            "state": state,
            "prompt": "none",
        }
    )

    return redirect(f"{DISCORD_OAUTH_AUTHORIZE_URL}?{params}")


@dashboard.get("/oauth/callback")
def dashboard_oauth_callback():
    if not AUTH_CONFIGURED:
        return render_template(
            "oauth_error.html",
            error="Discord authentication is not configured yet.",
        ), 503

    returned_state = request.args.get("state", "")
    expected_state = session.pop("oauth_state", "")

    if not returned_state or not secrets.compare_digest(
        returned_state,
        expected_state,
    ):
        return render_template(
            "oauth_error.html",
            error="Discord login state validation failed. Please try again.",
        ), 400

    code = request.args.get("code", "")
    if not code:
        return render_template(
            "oauth_error.html",
            error="Discord did not return an authorization code.",
        ), 400

    try:
        token_data = oauth_exchange_code(code)
        access_token = token_data.get("access_token", "")
        if not access_token:
            raise RuntimeError("Discord did not return an access token.")

        user = oauth_fetch_user(access_token)
    except Exception as exc:
        logging.exception("Discord OAuth login failed")
        return render_template(
            "oauth_error.html",
            error=f"Discord login failed: {exc}",
        ), 502

    next_url = session.get("oauth_next", "/")
    session.clear()
    session.permanent = True
    session["discord_user"] = {
        "id": str(user.get("id", "")),
        "username": user.get("username", "Unknown User"),
        "global_name": user.get("global_name"),
        "avatar": user.get("avatar"),
    }

    allowed = authorized_guilds_for_session()
    if not allowed:
        session["discord_user"]["avatar_url"] = discord_avatar_url(user)
        return render_template(
            "access_denied.html",
            current_user=session["discord_user"],
        ), 403

    session["discord_user"]["avatar_url"] = discord_avatar_url(user)
    # Only permit local relative redirects.
    if not next_url.startswith("/") or next_url.startswith("//"):
        next_url = "/"

    return redirect(next_url)


@dashboard.get("/logout")
def dashboard_logout():
    session.clear()
    return redirect(url_for("dashboard_login"))


@dashboard.get("/auth-status")
def dashboard_auth_status():
    return {
        "configured": AUTH_CONFIGURED,
        "logged_in": bool(current_dashboard_user()),
    }


def dashboard_context(selected_guild, message: str):
    online = bot.is_ready()
    guilds = authorized_guilds_for_session()
    update_state = dict(UPDATE_STATE)

    if update_state.get("error"):
        update_status = "CHECK FAILED"
        update_class = "red"
    elif update_state.get("available"):
        update_status = "UPDATE AVAILABLE"
        update_class = "yellow"
    elif update_state.get("checked"):
        update_status = "UP TO DATE"
        update_class = "green"
    else:
        update_status = "NOT CHECKED"
        update_class = ""

    latest_version = (
        f"V{update_state['latest_version']}"
        if update_state.get("latest_version")
        else "Unknown"
    )

    base_context = {
        "online": online,
        "latency": round(bot.latency * 1000) if online else 0,
        "guilds": guilds,
        "selected_guild_id": selected_guild.id if selected_guild else None,
        "guild": selected_guild,
        "message": message,
        "current_version": CURRENT_VERSION,
        "latest_version": latest_version,
        "update_status": update_status,
        "update_class": update_class,
        "update_available": bool(update_state.get("available")),
        "update_changelog": update_state.get("changelog", ""),
        "manifest_configured": bool(UPDATE_MANIFEST_URL),
        "update_error": update_state.get("error", ""),
        "auth_configured": AUTH_CONFIGURED,
        "current_user": current_dashboard_user(),
        "discord_redirect_uri": DISCORD_REDIRECT_URI,
        "remote_enabled": REMOTE_ACCESS_ENABLED,
        "remote_configured": REMOTE_ACCESS_CONFIGURED,
        "remote_status": REMOTE_STATE.get("status", "disabled"),
        "remote_public_url": REMOTE_STATE.get("public_url", ""),
        "remote_error": REMOTE_STATE.get("error", ""),
        "dashboard_server": REMOTE_STATE.get("server", "starting"),
    }

    if not selected_guild:
        return base_context

    cfg = get_cfg(selected_guild.id)

    channels = [
        {"id": channel.id, "name": channel.name}
        for channel in selected_guild.text_channels
    ]

    roles = [
        {"id": role.id, "name": role.name}
        for role in selected_guild.roles
        if not role.is_default() and not role.managed
    ]

    members = server_members(
        selected_guild.id,
        exclude_staff=False,
    )

    target_pool = server_members(
        selected_guild.id,
        exclude_staff=cfg.get("exclude_staff", True),
    )

    next_run = get_next(cfg)

    if next_run:
        delta = next_run - datetime.now(timezone.utc)
        next_ambush = (
            "Due now"
            if delta.total_seconds() <= 0
            else format_duration(delta.total_seconds())
        )
    else:
        next_ambush = "Not scheduled"

    with DATA_LOCK:
        recent_history = [
            dict(item)
            for item in history["entries"]
            if item.get("guild_id") == selected_guild.id
        ][:15]

    for item in recent_history:
        try:
            stamp = normalize_datetime(
                datetime.fromisoformat(item["timestamp"])
            )
            item["time_display"] = stamp.astimezone().strftime(
                "%b %d, %I:%M %p"
            )
        except Exception:
            item["time_display"] = "Unknown"

    base_context.update(
        {
            "cfg": {
                "channel_id": cfg.get("channel_id"),
                "enabled": cfg.get("enabled", True),
                "exclude_staff": cfg.get("exclude_staff", True),
                "min_minutes": cfg.get("min_minutes", 180),
                "max_minutes": cfg.get("max_minutes", 720),
            },
            "channels": channels,
            "member_pool": members,
            "target_pool_count": len(target_pool),
            "next_ambush": next_ambush,
            "recent_history": recent_history,
            "uptime": format_duration(
                (
                    datetime.now(timezone.utc)
                    - BOT_STARTED_AT
                ).total_seconds()
            ),
            "roles": roles,
            "staff_role_ids": get_staff_role_ids(selected_guild.id),
            "dashboard_access_role_ids": get_dashboard_access_role_ids(selected_guild.id),
        }
    )

    return base_context


def maybe_refresh_update_state() -> None:
    """Refresh the update feed in the background when the dashboard opens."""
    if not UPDATE_MANIFEST_URL:
        return

    last_checked = UPDATE_STATE.get("last_checked_at")
    now = datetime.now(timezone.utc).timestamp()

    if last_checked and (now - float(last_checked)) < 10:
        return

    def _check() -> None:
        try:
            check_for_update(UPDATE_MANIFEST_URL)
        except Exception:
            logging.exception("Dashboard-triggered update check failed")

    threading.Thread(
        target=_check,
        name="DZG-Jarvis-Update-Refresh",
        daemon=True,
    ).start()


@dashboard.get("/")
def dashboard_home():
    maybe_refresh_update_state()
    guilds = authorized_guilds_for_session()

    if AUTH_CONFIGURED and not guilds:
        return render_template(
            "access_denied.html",
            current_user=current_dashboard_user(),
        ), 403

    requested_id = request.args.get("guild_id", type=int)
    selected_guild = None

    if requested_id:
        selected_guild = next(
            (guild for guild in guilds if guild.id == requested_id),
            None,
        )

    if selected_guild is None and guilds:
        selected_guild = guilds[0]

    return render_template(
        "dashboard.html",
        **dashboard_context(
            selected_guild,
            request.args.get("message", ""),
        ),
    )


@dashboard.post("/permissions")
def dashboard_permissions():
    guild_id = int(request.form["guild_id"])
    role_ids = [
        int(value)
        for value in request.form.getlist("role_ids")
    ]

    set_staff_role_ids(guild_id, role_ids)

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message="Jarvis staff roles saved.",
        )
    )


@dashboard.post("/check-update")
def dashboard_check_update():
    guild_id = int(request.form["guild_id"])
    state = check_for_update(UPDATE_MANIFEST_URL)

    if state.get("error"):
        message = f"Update check failed: {state['error']}"
    elif state.get("available"):
        message = f"Update V{state['latest_version']} is available."
    else:
        message = "Jarvis is up to date."

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message=message,
        )
    )


@dashboard.get("/health")
def dashboard_health():
    return {
        "ok": True,
        "version": CURRENT_VERSION,
        "bot_ready": bot.is_ready(),
    }


@dashboard.get("/update-status")
def dashboard_update_status():
    return dict(UPDATE_INSTALL_STATE)


@dashboard.post("/install-update")
def dashboard_install_update():
    guild_id = int(request.form["guild_id"])
    manifest = UPDATE_STATE.get("manifest")

    if not manifest or not UPDATE_STATE.get("available"):
        return redirect(
            url_for(
                "dashboard_home",
                guild_id=guild_id,
                message="No update is currently available.",
            )
        )

    target_version = str(manifest.get("version", "")).strip()
    if not target_version:
        return redirect(
            url_for(
                "dashboard_home",
                guild_id=guild_id,
                message="Update manifest is missing a target version.",
            )
        )

    if UPDATE_INSTALL_STATE.get("status") in {"installing", "restarting"}:
        return render_template(
            "restarting.html",
            guild_id=guild_id,
            target_version=UPDATE_INSTALL_STATE.get("target_version") or target_version,
        )

    UPDATE_INSTALL_STATE.update(
        {
            "status": "installing",
            "message": f"Installing Jarvis V{target_version}...",
            "target_version": target_version,
        }
    )

    def _install_and_restart() -> None:
        # Give Flask enough time to send the restart page to the browser
        # before the current Jarvis process shuts itself down.
        time.sleep(1.0)

        try:
            result = apply_update(BASE, manifest)
            UPDATE_INSTALL_STATE.update(
                {
                    "status": "restarting",
                    "message": f"{result} Restarting Jarvis...",
                }
            )
            time.sleep(0.5)
            restart_process(BASE)
        except Exception as exc:
            logging.exception("Update installation failed")
            UPDATE_INSTALL_STATE.update(
                {
                    "status": "failed",
                    "message": f"Update failed: {exc}",
                }
            )

    threading.Thread(
        target=_install_and_restart,
        name="DZG-Jarvis-Update-Installer",
        daemon=True,
    ).start()

    return render_template(
        "restarting.html",
        guild_id=guild_id,
        target_version=target_version,
    )


@dashboard.post("/dashboard-access-roles")
def dashboard_access_roles():
    guild_id = int(request.form["guild_id"])
    role_ids = request.form.getlist("dashboard_access_role_ids")
    set_dashboard_access_role_ids(guild_id, [int(role_id) for role_id in role_ids])

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message="Dashboard access permissions updated.",
        )
    )


@dashboard.post("/settings")
def dashboard_settings():
    guild_id = int(request.form["guild_id"])
    cfg = get_cfg(guild_id)

    channel_raw = request.form.get("channel_id", "")
    cfg["channel_id"] = int(channel_raw) if channel_raw else None
    cfg["enabled"] = request.form.get("enabled") == "1"
    cfg["exclude_staff"] = request.form.get("exclude_staff") == "1"

    try:
        min_minutes = max(
            5,
            int(request.form.get("min_minutes", "180")),
        )
        max_minutes = max(
            5,
            int(request.form.get("max_minutes", "720")),
        )
    except ValueError:
        return redirect(
            url_for(
                "dashboard_home",
                guild_id=guild_id,
                message="Invalid wait time.",
            )
        )

    if max_minutes < min_minutes:
        return redirect(
            url_for(
                "dashboard_home",
                guild_id=guild_id,
                message=(
                    "Maximum wait must be greater than "
                    "or equal to minimum wait."
                ),
            )
        )

    cfg["min_minutes"] = min_minutes
    cfg["max_minutes"] = max_minutes
    save_json(CONFIG_PATH, config)

    wait = schedule_next(guild_id)

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message=(
                "Settings saved. Next ambush rerolled "
                f"for about {wait} minutes from now."
            ),
        )
    )


@dashboard.post("/reroll")
def dashboard_reroll():
    guild_id = int(request.form["guild_id"])
    wait = schedule_next(guild_id)

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message=(
                "Next ambush rerolled for about "
                f"{wait} minutes from now."
            ),
        )
    )


@dashboard.post("/random-ban")
def dashboard_random_ban():
    guild_id = int(request.form["guild_id"])

    _, result = run_on_bot(
        send_dashboard_fakeban(
            guild_id,
            target_id=None,
            source="dashboard-random",
        )
    )

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message=result,
        )
    )


@dashboard.post("/manual-ban")
def dashboard_manual_ban():
    guild_id = int(request.form["guild_id"])
    target_id = int(request.form["target_id"])

    _, result = run_on_bot(
        send_dashboard_fakeban(
            guild_id,
            target_id=target_id,
            source="dashboard-manual",
        )
    )

    return redirect(
        url_for(
            "dashboard_home",
            guild_id=guild_id,
            message=result,
        )
    )


def run_dashboard():
    try:
        from waitress import serve

        REMOTE_STATE["server"] = "waitress"
        logging.info(
            "Starting Waitress dashboard server at http://%s:%s",
            DASHBOARD_HOST,
            DASHBOARD_PORT,
        )
        serve(
            dashboard,
            host=DASHBOARD_HOST,
            port=DASHBOARD_PORT,
            threads=8,
        )
    except ImportError:
        REMOTE_STATE["server"] = "flask-fallback"
        logging.warning(
            "Waitress is not installed yet; using Flask fallback server."
        )
        dashboard.run(
            host=DASHBOARD_HOST,
            port=DASHBOARD_PORT,
            debug=False,
            use_reloader=False,
        )
    except Exception:
        REMOTE_STATE["server"] = "failed"
        logging.exception("Dashboard server failed")


def start_remote_tunnel():
    if not REMOTE_ACCESS_ENABLED:
        REMOTE_STATE.update(
            {
                "status": "disabled",
                "configured": False,
                "error": "",
            }
        )
        return

    if not REMOTE_ACCESS_CONFIGURED:
        missing = []
        if not NGROK_AUTHTOKEN:
            missing.append("NGROK_AUTHTOKEN")
        if not NGROK_DOMAIN:
            missing.append("NGROK_DOMAIN")
        if not DASHBOARD_PUBLIC_URL:
            missing.append("DASHBOARD_PUBLIC_URL")
        if not AUTH_CONFIGURED:
            missing.append("Discord OAuth settings")

        REMOTE_STATE.update(
            {
                "status": "setup-required",
                "configured": False,
                "error": "Missing: " + ", ".join(missing),
            }
        )
        return

    try:
        # Give Waitress time to bind the local port before publishing it.
        time.sleep(2.0)

        from pyngrok import conf, ngrok

        pyngrok_config = conf.PyngrokConfig(
            auth_token=NGROK_AUTHTOKEN,
            config_version="3",
            startup_timeout=30,
        )

        try:
            ngrok.kill(pyngrok_config=pyngrok_config)
        except Exception:
            pass

        expected_url = normalize_public_url(DASHBOARD_PUBLIC_URL)
        tunnel = ngrok.connect(
            addr=f"http://127.0.0.1:{DASHBOARD_PORT}",
            name="dzg-jarvis-dashboard",
            pyngrok_config=pyngrok_config,
            url=expected_url,
        )
        actual_url = normalize_public_url(tunnel.public_url)

        if actual_url != expected_url:
            raise RuntimeError(
                f"ngrok opened {actual_url}, expected {expected_url}."
            )

        REMOTE_STATE.update(
            {
                "status": "online",
                "configured": True,
                "public_url": actual_url,
                "error": "",
            }
        )
        logging.info("Remote Jarvis dashboard online at %s", actual_url)
    except ImportError:
        REMOTE_STATE.update(
            {
                "status": "dependency-missing",
                "configured": False,
                "error": (
                    "pyngrok is not installed yet. Restart Jarvis after "
                    "dependency installation completes."
                ),
            }
        )
        logging.exception("pyngrok is unavailable")
    except Exception as exc:
        REMOTE_STATE.update(
            {
                "status": "failed",
                "configured": False,
                "error": str(exc),
            }
        )
        logging.exception("Could not start secure remote dashboard tunnel")


def main():
    threading.Thread(
        target=run_dashboard,
        name="DZG-Jarvis-Dashboard",
        daemon=True,
    ).start()

    threading.Thread(
        target=start_remote_tunnel,
        name="DZG-Jarvis-Remote-Tunnel",
        daemon=True,
    ).start()

    bot.run(TOKEN)


if __name__ == "__main__":
    main()

DZG JARVIS V1.8 COMPLETE DROP-IN UPDATE

WHAT V1.8 ADDS

UPDATE CENTER
- Current version display
- Latest version display
- Check for Updates button
- Update Available state
- Changelog preview
- Update Jarvis Now button
- Automatic backup before updates
- Optional SHA-256 verification
- Preserves your .env and Jarvis data/config JSON files
- Automatic restart after an update
- Automatic update checking every 6 hours once configured

PERMISSIONS
- All Jarvis slash commands now use one centralized staff check
- Discord management permissions still count as staff
- Dashboard can select extra Discord roles that count as Jarvis Staff
- Role settings persist separately for each Discord server

DASHBOARD
- Keeps the V1.7 fake-ban dashboard
- Random ambush controls
- Manual and random fake bans
- Fake-ban history
- Multi-server support
- New Update Center
- New Staff Permissions panel

INSTALL V1.8

1. STOP JARVIS.

Because you use the hidden launcher:
- Open Task Manager
- Go to Details
- End the python.exe process running Jarvis

2. BACK UP YOUR EXISTING DZG_JARVIS_V1 FOLDER.

3. EXTRACT THIS ZIP.

4. Copy these into your existing DZG_JARVIS_V1 folder:

- bot.py
- updater.py
- permissions.py
- requirements.txt
- templates folder

Replace bot.py and requirements.txt when Windows asks.

DO NOT replace or delete:
- .env
- fakeban_config.json
- fakeban_activity.json
- fakeban_history.json

5. Open Command Prompt inside DZG_JARVIS_V1 and run:

python -m pip install -r requirements.txt

6. Close Command Prompt after installation completes.

7. Start Jarvis with:

Start_DZG_Jarvis_Hidden.vbs

8. Open:

http://127.0.0.1:5000

You should see Version 1.8.0, the Update Center, and Staff Permissions.

UPDATE FEED SETUP

The Update Center needs a public version.json file.

After we host one, add this line to .env:

UPDATE_MANIFEST_URL=https://YOUR-HOST/version.json

Until then the dashboard will show:

UPDATE FEED: NOT CONFIGURED

Jarvis will still work normally.

FUTURE UPDATE FLOW

1. Jarvis checks version.json automatically every 6 hours.
2. Dashboard shows UPDATE AVAILABLE.
3. You click UPDATE JARVIS NOW.
4. Jarvis downloads the update.
5. Jarvis verifies the SHA-256 hash if provided.
6. Jarvis creates a backup.
7. Jarvis installs new files.
8. Jarvis preserves your private settings and data.
9. Jarvis restarts itself.

V1.8 does not silently install updates.
You still approve them with the Update Jarvis Now button.

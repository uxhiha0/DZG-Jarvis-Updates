from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.parse
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

CURRENT_VERSION = "1.8.6"

PRESERVE_NAMES = {
    ".env",
    "fakeban_config.json",
    "fakeban_activity.json",
    "fakeban_history.json",
    "permissions_config.json",
}

UPDATE_STATE: dict[str, Any] = {
    "checked": False,
    "available": False,
    "latest_version": None,
    "changelog": "",
    "manifest": None,
    "error": None,
    "last_checked_at": None,
}


def version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for piece in value.strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)


def fetch_manifest(manifest_url: str, timeout: int = 10) -> dict[str, Any]:
    if not manifest_url:
        raise RuntimeError("UPDATE_MANIFEST_URL is not configured in .env.")

    parsed = urllib.parse.urlsplit(manifest_url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.append(("_dzg_ts", str(int(time.time() * 1000))))
    fresh_url = urllib.parse.urlunsplit(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            urllib.parse.urlencode(query),
            parsed.fragment,
        )
    )

    request = urllib.request.Request(
        fresh_url,
        headers={
            "User-Agent": f"DZG-Jarvis/{CURRENT_VERSION}",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )

    with urllib.request.urlopen(request, timeout=timeout) as response:
        data = json.loads(response.read().decode("utf-8"))

    if not isinstance(data, dict):
        raise RuntimeError("Update manifest must be a JSON object.")
    if not data.get("version"):
        raise RuntimeError("Update manifest is missing 'version'.")
    if not data.get("zip_url"):
        raise RuntimeError("Update manifest is missing 'zip_url'.")

    return data

def check_for_update(manifest_url: str) -> dict[str, Any]:
    try:
        manifest = fetch_manifest(manifest_url)
        latest = str(manifest["version"])
        available = version_tuple(latest) > version_tuple(CURRENT_VERSION)

        UPDATE_STATE.update(
            {
                "checked": True,
                "available": available,
                "latest_version": latest,
                "changelog": str(manifest.get("changelog", "")),
                "manifest": manifest,
                "error": None,
                "last_checked_at": time.time(),
            }
        )
    except Exception as exc:
        UPDATE_STATE.update(
            {
                "checked": True,
                "available": False,
                "latest_version": None,
                "changelog": "",
                "manifest": None,
                "error": str(exc),
                "last_checked_at": time.time(),
            }
        )

    return dict(UPDATE_STATE)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_extract(zip_path: Path, destination: Path) -> None:
    destination_resolved = destination.resolve()

    with zipfile.ZipFile(zip_path, "r") as archive:
        for member in archive.infolist():
            name = member.filename.replace("\\", "/")
            if name.endswith("/"):
                continue

            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError(f"Unsafe path inside update ZIP: {name}")

            target = (destination / relative).resolve()
            if target != destination_resolved and destination_resolved not in target.parents:
                raise RuntimeError(f"Unsafe extraction target: {name}")

            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member, "r") as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def find_payload_root(extracted: Path) -> Path:
    if (extracted / "bot.py").exists():
        return extracted

    for child in extracted.iterdir():
        if child.is_dir() and (child / "bot.py").exists():
            return child

    raise RuntimeError("Update ZIP does not contain bot.py.")


def create_backup(base_dir: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = base_dir / "backups" / f"v{CURRENT_VERSION}_{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    for item in base_dir.iterdir():
        if item.name in {"backups", "__pycache__"}:
            continue

        if item.is_file():
            shutil.copy2(item, backup_dir / item.name)

    return backup_dir


def apply_update(base_dir: Path, manifest: dict[str, Any]) -> str:
    zip_url = str(manifest["zip_url"])
    expected_hash = str(manifest.get("sha256", "")).strip().lower()

    with tempfile.TemporaryDirectory(prefix="dzg_jarvis_update_") as temp_name:
        temp_dir = Path(temp_name)
        zip_path = temp_dir / "update.zip"
        extracted = temp_dir / "payload"
        extracted.mkdir(parents=True, exist_ok=True)

        request = urllib.request.Request(
            zip_url,
            headers={"User-Agent": f"DZG-Jarvis/{CURRENT_VERSION}"},
        )

        with urllib.request.urlopen(request, timeout=45) as response:
            zip_path.write_bytes(response.read())

        if expected_hash and sha256(zip_path) != expected_hash:
            raise RuntimeError(
                "Update checksum failed. Downloaded file does not match manifest."
            )

        safe_extract(zip_path, extracted)
        payload_root = find_payload_root(extracted)
        backup_dir = create_backup(base_dir)

        for source in payload_root.rglob("*"):
            if not source.is_file():
                continue

            relative = source.relative_to(payload_root)

            if relative.name in PRESERVE_NAMES:
                continue
            if relative.parts and relative.parts[0] in {"backups", "__pycache__"}:
                continue

            destination = base_dir / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)

    return f"Update installed. Backup saved as {backup_dir.name}."


def restart_process(base_dir: Path, delay: float = 2.0) -> None:
    """Restart Jarvis after the current process fully exits.

    A detached helper waits for this process to die before launching bot.py.
    This avoids the old Flask server still holding port 5000 while the new
    process starts.
    """
    import subprocess

    helper = base_dir / "restart_helper.py"

    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )

    subprocess.Popen(
        [
            sys.executable,
            str(helper),
            str(os.getpid()),
            str(base_dir),
            str(delay),
        ],
        cwd=str(base_dir),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
        creationflags=creationflags,
    )

    # Exit immediately so Discord and Flask release their sockets/ports.
    os._exit(0)
